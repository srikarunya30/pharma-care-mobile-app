package com.pharmacare.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Splash Screen
 * Shows the PharmaCare logo, app name and tagline for 3 seconds,
 * then navigates to Home (if a session exists) or Login (if not).
 *
 * Session state is kept in SharedPreferences ("PharmaCarePrefs" / "isLoggedIn"),
 * since SQLite has no built-in concept of "current session" like Firebase Auth does.
 */
public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DELAY_MS = 3000; // 3 seconds
    public static final String PREFS_NAME = "PharmaCarePrefs";
    public static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    public static final String KEY_USER_EMAIL = "loggedInEmail";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false);

            Intent intent;
            if (isLoggedIn) {
                // Home screen not built yet in this milestone; placeholder target.
                intent = new Intent(SplashActivity.this, LoginActivity.class);
                intent.putExtra("skipToHome", true);
            } else {
                intent = new Intent(SplashActivity.this, LoginActivity.class);
            }
            startActivity(intent);
            finish();
        }, SPLASH_DELAY_MS);
    }
}
