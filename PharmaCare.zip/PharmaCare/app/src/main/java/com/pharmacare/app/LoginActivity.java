package com.pharmacare.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Login Screen
 * Fields: Email, Password
 * Buttons: Login, Register, Forgot Password
 * Validation: required fields, valid email format, password >= 6 characters.
 * Backend: SQLite via DatabaseHelper (replaces Firebase Authentication).
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin, btnRegister;
    private TextView tvForgotPassword;
    private ProgressBar progressBar;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        progressBar = findViewById(R.id.progressBar);

        btnLogin.setOnClickListener(v -> attemptLogin());

        btnRegister.setOnClickListener(v ->
                Toast.makeText(this, "Register screen coming in next milestone", Toast.LENGTH_SHORT).show()
                // startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        );

        tvForgotPassword.setOnClickListener(v ->
                Toast.makeText(this, "Forgot Password screen coming in next milestone", Toast.LENGTH_SHORT).show()
        );
    }

    private void attemptLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // --- Validation ---
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter a valid email address");
            etEmail.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return;
        }
        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            etPassword.requestFocus();
            return;
        }

        // --- SQLite check ---
        progressBar.setVisibility(View.VISIBLE);
        boolean isValid = dbHelper.checkLogin(email, password);
        progressBar.setVisibility(View.GONE);

        if (isValid) {
            // Persist session so Splash -> Home works next launch
            SharedPreferences prefs = getSharedPreferences(SplashActivity.PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                    .putBoolean(SplashActivity.KEY_IS_LOGGED_IN, true)
                    .putString(SplashActivity.KEY_USER_EMAIL, email)
                    .apply();

            String userName = dbHelper.getUserName(email);
            Toast.makeText(this, "Welcome back, " + userName + "!", Toast.LENGTH_SHORT).show();

            // Home screen Activity to be added in the next milestone.
            // Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            // startActivity(intent);
            // finish();
        } else {
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
        }
    }
}
